<?php
/**
 * Created by PhpStorm.
 * User: Joselito
 * Date: 28/03/2018
 * Time: 09:35
 */

class Journal  extends CI_Model
{
    public function getAll(){

        $this->load->database();
        $query= $this->db->get("journal");
        $data=$query->result();
        $this->db->close();
        return $data;

    }
    public function getById($id){
        $this->load->database();
        $query= $this->db->select('*')->from('journal')->where('Id',$id)->get();
        $data=$query->result();
        $this->db->close();
        return $data;
    }

    public function insert($n,$pr,$te,$md,$t,$a){
        $this->load->database();

        $data = array(

            'idType' =>$n,
            'titre'=>$pr,
            'daty'=>$te,
            'content' =>$md,
            'degre'=>$t,
            'image' =>$a
        );
        $this->db->insert("journal", $data);
    }
    public function update($id,$n,$pr,$te,$md,$t,$a){
        $this->load->database();

        $data = array(

            'idType' =>$n,
            'titre'=>$pr,
            'daty'=>$te,
            'content' =>$md,
            'degre'=>$t,
            'image' =>$a
        );
        $this->db->set($data);
        $this->db->where("Id",$id);
        $this->db->update("journal", $data);
    }
    public function getAccueil(){
        $this->load->database();
        $data=$this->db->query("select accueil.Id as Id,categorie.nom as idType,journal.titre as titre,journal.daty as daty,journal.content as content,journal.degre as degre,journal.image as image from journal join accueil on accueil.idJournal=journal.Id join categorie on categorie.Id=journal.idType");
        $this->db->close();
        return $data->result_array();
    }
    public function getByCategorie($id){
        $this->load->database();
        $data=$this->db->query("select * from journal where idType='".$id."' order by Id desc limit 4 ");
        $this->db->close();
        return $data->result_array();
    }
    public function getByDesc(){
        $this->load->database();
        $data=$this->db->query("select * from journal order by Id desc limit 4");
        $this->db->close();
        return $data->result_array();
    }
    public function getByDesc2(){
        $this->load->database();
        $data=$this->db->query("select journal.Id as Id,categorie.nom as idType,journal.titre as titre,journal.daty as daty,journal.content as content,journal.degre as degre,journal.image as image from journal join categorie on categorie.Id=journal.idType");
        $this->db->close();
        return $data->result_array();
    }
    public function updateAccueil($id,$n){
        $this->load->database();

        $data = array(


            'idJournal'=>$n
        );

        $this->db->set($data);
        $this->db->where("Id",$id);
        $this->db->update("accueil", $data);
    }

}