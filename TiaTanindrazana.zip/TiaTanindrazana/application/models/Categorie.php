<?php
/**
 * Created by PhpStorm.
 * User: Joselito
 * Date: 28/03/2018
 * Time: 09:56
 */

class Categorie   extends CI_Model
{
    public function getAll(){

        $this->load->database();
        $query= $this->db->get("categorie");
        $data=$query->result();
        $this->db->close();
        return $data;

    }
    public function getById($id){
        $this->load->database();
        $query= $this->db->select('*')->from('categorie')->where('Id',$id)->get();
        $data=$query->result();
        $this->db->close();
        return $data;
    }

    public function insert($pr){
        $this->load->database();

        $data = array(
            'nom'=>$pr
        );
        $this->db->insert("categorie", $data);
    }
    public function update($id,$n){
        $this->load->database();

        $data = array(


            'nom'=>$n
        );

        $this->db->set($data);
        $this->db->where("Id",$id);
        $this->db->update("categorie", $data);
    }
}