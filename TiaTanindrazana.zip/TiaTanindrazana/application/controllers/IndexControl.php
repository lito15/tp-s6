<?php
/**
 * Created by PhpStorm.
 * User: Joselito
 * Date: 31/03/2018
 * Time: 20:03
 */

class IndexControl extends CI_Controller
{
    public function index()
    {
        $this->load->helper('url');
        $data['contenu'] = "front/index";
        $data['title'] = "Le journal pour vous";
        date_default_timezone_set('Europe/London');
        $data['dateNow']=date('d-m-Y');
        $this->load->model('Categorie');
        $this->load->model('Journal');
        $data['allCategorie']=$this->Categorie->getAll();
        $data['newAccueil']=$this->Journal->getAccueil();
        $this->load->view('front/templates/template', $data);
    }

    public function fiche(){
        $this->load->helper('url');
        $id= $this->input->get('id', TRUE);
        $this->load->model('Categorie');
        $this->load->model('Journal');
        date_default_timezone_set('Europe/London');
        $data['dateNow']=date('d-m-Y');
        $data['allCategorie']=$this->Categorie->getAll();
        $data['fiche']=$this->Journal->getById($id);
        $data['contenu'] = "front/fiche";
        foreach($data['fiche'] as $row){
            $data['title'] = "Le journal - ".$row->titre;
        }

        $this->load->view('front/templates/template', $data);
    }
    public function byCategorie(){
        $this->load->helper('url');
        $id=$this->input->get('id', TRUE);
        $this->load->model('Categorie');
        $this->load->model('Journal');
        date_default_timezone_set('Europe/London');
        $data['dateNow']=date('d-m-Y');
        $data['allCategorie']=$this->Categorie->getAll();
        $data['cate']=$this->Categorie->getById($id);
        $data['fiche']=$this->Journal->getByCategorie($id);
        foreach($data['cate'] as $row){
            $data['title'] = "Le journal categorie- ".$row->nom;
        }
        $data['contenu'] = "front/byCategorie";
        $this->load->view('front/templates/template', $data);
    }
}