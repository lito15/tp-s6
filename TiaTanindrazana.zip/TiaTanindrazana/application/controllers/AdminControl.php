<?php
/**
 * Created by PhpStorm.
 * User: Joselito
 * Date: 04/04/2018
 * Time: 19:33
 */

class AdminControl extends CI_Controller
{
    public function index()
    {
        $this->load->helper('url');
        $data['contenu'] = "back/accueil";
        date_default_timezone_set('Europe/London');
        $data['dateNow']=date('d-m-Y');
        $this->load->model('Categorie');
        $this->load->model('Journal');
        $data['allCategorie']=$this->Categorie->getAll();
        $data['newAccueil']=$this->Journal->getAccueil();
        $this->load->view('back/templates/template', $data);
    }

}