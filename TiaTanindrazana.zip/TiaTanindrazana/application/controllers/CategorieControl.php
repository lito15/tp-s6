<?php
/**
 * Created by PhpStorm.
 * User: Joselito
 * Date: 04/04/2018
 * Time: 20:29
 */

class CategorieControl extends CI_Controller
{
    public function index()
    {
        $this->load->helper('url');
        $data['contenu'] = "back/type";
        $this->load->view('back/templates/template', $data);
    }
}