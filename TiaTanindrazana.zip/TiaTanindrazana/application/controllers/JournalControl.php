<?php
/**
 * Created by PhpStorm.
 * User: Joselito
 * Date: 04/04/2018
 * Time: 20:32
 */

class JournalControl extends CI_Controller
{
    public function index()
    {
        $this->load->helper('url');
        $data['contenu'] = "back/journal";
        $this->load->model('Categorie');
        $data['allCategorie']=$this->Categorie->getAll();
        $this->load->view('back/templates/template', $data);
    }
    public function insert(){
        $config['upload_path']='./images/article/';
        $config['allowed_types']='.gif|jpg|png';
        //$config['file_name']=$_POST['userfile'];
        $config['max_size']=2048;
        $config['max_width']=2000;
        $config['max_height']=2000;
        $this->load->library('upload',$config);
        if($this->upload->do_upload('userfile')){
            $this->load->helper('url');
            $data['upload_data']=$this->upload->data();
            $file_name='';
            $i=0;
            foreach($data['upload_data'] as $item => $value){
                if($i==0){
                    $file_name=$value;
                }
                $i++;
            }
            $this->load->model('Journal');
            $this->Journal->insert($_POST['categorie'],$_POST['titre'],$_POST['date'],$_POST['content'],"11",$file_name);
            $data['contenu'] = "back/liste";
            $this->load->model('Journal');
            $data['all']=$this->Journal->getByDesc();
            $this->load->view('back/templates/template', $data);
        }
    }
    public function liste(){
        $this->load->helper('url');
        $data['contenu'] = "back/liste";
        $this->load->model('Journal');
        $data['all']=$this->Journal->getByDesc();
        $this->load->view('back/templates/template', $data);
    }
    public function liste2(){
        $this->load->library('session');
        $this->load->helper('url');
        $id=$this->input->get('id', TRUE);
        $this->session->set_userdata('Id',$id);
        $data['contenu'] = "back/listeChoix";
        $this->load->model('Journal');
        $data['all']=$this->Journal->getByDesc2();
        $this->load->view('back/templates/template', $data);
    }
    public function updateAccueil(){
        $this->load->library('session');
        $this->load->helper('url');
        $id=$this->session->userdata('Id');
        $this->load->model('Journal');
        $this->Journal->updateAccueil($id,$this->input->get('id', TRUE));
        $data['contenu'] = "back/accueil";
        date_default_timezone_set('Europe/London');
        $data['dateNow']=date('d-m-Y');
        $this->load->model('Categorie');
        $data['allCategorie']=$this->Categorie->getAll();
        $data['newAccueil']=$this->Journal->getAccueil();
        $this->load->view('back/templates/template', $data);
    }

}