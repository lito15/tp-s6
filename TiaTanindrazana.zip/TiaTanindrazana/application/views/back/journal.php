<?php
/**
 * Created by PhpStorm.
 * User: Joselito
 * Date: 23/01/2018
 * Time: 09:48
 */
?>
<script type="text/javascript">
    $(document).ready(function(){
        console.log("test");
        $('#sport').on('change',function(){
            var categorieID = $(this).val();
            if(categorieID){
                $.ajax({
                   /* type: 'POST',
                    url: 'SousCategorieControl/getByCategorie',
                    data: 'categorie=' + categorieID,
                    success: function (html) {
                        $('#souscat').html(html);
                    }
                    */

                });
            }
        });
    });
</script>
<div id="content" xmlns:javascript="http://www.w3.org/1999/xhtml">
    <div class="outer">
        <div class="inner bg-light lter">
            <div class="row">
                <div class="col-lg-12">
                    <div class="box">
                        <header class="dark">
                            <div class="icons"><i class="fa fa-cloud-upload"></i></div>
                            <h5>Quelle nouvelle aujourd'hui?</h5>
                        </header>
                        <div class="body">
                            <form Method="post" action="<?php echo base_url(); ?>InsertJ"  enctype="multipart/form-data" class="form-horizontal">
                                <div class="form-group">
                                    <label class="control-label col-lg-4">grand titre</label>
                                    <div class="col-lg-4">
                                        <input type="text" class="validate[required] form-control" name="titre" id="req">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-lg-4">type</label>
                                    <div class="col-lg-4">
                                        <select name="categorie" id="sport" class="validate[required] form-control">
                                        <?php foreach ($allCategorie as $row) { ?>
                                            <option value="<?php echo ($row->Id); ?>"><?php echo ($row->nom); ?></option>
                                            <?php  }  ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="autosize" class="control-label col-lg-4">contenue</label>

                                    <div class="col-lg-8">
                                        <textarea id="autosize"  name="content" class="form-control"></textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-lg-4">Inserer une Image descriptive</label>
                                    <div class="col-lg-8">
                                        <input type="file" name="userfile" size="20" />

                                    </div>

                                </div>
                                <div class="form-group">
                                    <label class="control-label col-lg-4">date</label>
                                    <div class="col-lg-4">
                                        <input type="date" class="validate[required] form-control" name="date" id="req">
                                    </div>
                                </div>

                                <div class="alert alert-warning"><strong>Important!</strong> veuillez selectionner une image avec une bonne qualité</div>

                                <div class="control-label col-lg-4">
                                    <input type="submit" value="Validate" class="btn btn-primary">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.inner -->
    </div>
    <!-- /.outer -->
</div>
