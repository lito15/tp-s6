<?php
/**
 * Created by PhpStorm.
 * User: Joselito
 * Date: 22/01/2018
 * Time: 11:44
 */
?>
<div id="content">
    <div class="outer">
        <div class="inner bg-light lter">
            <style>
                .form-control.col-lg-6 {
                    width: 50% !important;
                }
            </style>
            <div class="row">
                <div class="col-lg-12">
                    <div class="box">
                        <header class="dark">
                            <div class="icons"><i class="fa fa-check"></i></div>
                            <h5>ajout categorie</h5>
                            <!-- .toolbar -->
                            <div class="toolbar">
                                <nav style="padding: 8px;">
                                    <a href="javascript:;" class="btn btn-default btn-xs collapse-box">
                                        <i class="fa fa-minus"></i>
                                    </a>
                                    <a href="javascript:;" class="btn btn-default btn-xs full-box">
                                        <i class="fa fa-expand"></i>
                                    </a>
                                    <a href="javascript:;" class="btn btn-danger btn-xs close-box">
                                        <i class="fa fa-times"></i>
                                    </a>
                                </nav>
                            </div>            <!-- /.toolbar -->

                        </header>
                        <div id="collapse2" class="body">
                            <form method="post" action="<?php echo base_url(); ?>CategorieControl/insert" class="form-horizontal" id="popup-validation">

                                <div class="form-group">
                                    <label class="control-label col-lg-4">nom</label>
                                    <div class="col-lg-4">
                                        <input type="text" class="validate[required] form-control" name="nom" id="req">
                                    </div>
                                </div>
                                <div class="form-actions no-margin-bottom">
                                    <input type="submit" value="Validate" class="btn btn-primary">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->


    <!-- /.outer -->
        </div>
    </div>
</div>




<!-- /#content -->
