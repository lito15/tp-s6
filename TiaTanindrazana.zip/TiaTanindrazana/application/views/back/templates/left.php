<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 22/01/2018
 * Time: 10:45
 */
$baseUrl = base_url();
?>
<div id="left">
    <div class="media user-media bg-dark dker">
        <div class="user-media-toggleHover">
            <span class="fa fa-user"></span>
        </div>
        <div class="user-wrapper bg-dark">
            <a class="user-link" href="">
                <img width="64" height="64" class="media-object img-thumbnail user-img" alt="User Picture" src="<?php echo $baseUrl ?>assets/images/back/user.jpg">
            </a>

            <div class="media-body">
                <h5 class="media-heading">User</h5>
                <ul class="list-unstyled user-info">
                    <li><a href="#">Administrateur</a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- #menu -->
    <ul id="menu" class="bg-blue dker">
        <li class="nav-header">Menu</li>
        <li class="nav-divider"></li>
        <li class="">
            <a href="<?php echo $baseUrl ?>">
                <i class="fa fa-dashboard"></i><span class="link-title">Visualiser le site</span>
            </a>
        </li>
        <li class="">
            <a href="javascript:;">
                <i class="fa fa-table"></i>
                <span class="link-title">
					Ajout
			  </span>
                <span class="fa arrow"></span>
            </a>
            <ul class="collapse">
                <li>
                    <a href="<?php echo base_url(); ?>ajoutJournal">
                        <i class="fa fa-angle-right"></i>&nbsp; nouvelle
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>ajoutType">
                        <i class="fa fa-angle-right"></i>&nbsp;type
                    </a>
                </li>
            </ul>
        </li>
    </ul>
    <!-- /#menu -->
</div>
<!-- /#left -->