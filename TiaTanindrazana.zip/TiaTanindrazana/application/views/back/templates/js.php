<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 22/01/2018
 * Time: 10:48
 */
$baseUrl = base_url();
?>
<!--jQuery -->
<script src="<?php echo $baseUrl ?>assets/assets/lib/back/jquery/jquery.js"></script>


<!--Bootstrap -->
<script src="<?php echo $baseUrl ?>assets/assets/lib/back/bootstrap/js/bootstrap.js"></script>
<!-- MetisMenu -->
<script src="<?php echo $baseUrl ?>assets/assets/lib/back/metismenu/metisMenu.js"></script>
<!-- onoffcanvas -->
<script src="<?php echo $baseUrl ?>assets/assets/lib/back/onoffcanvas/onoffcanvas.js"></script>
<!-- Screenfull -->
<script src="<?php echo $baseUrl ?>assets/assets/lib/back/screenfull/screenfull.js"></script>


<!-- Metis core scripts -->
<script src="<?php echo $baseUrl ?>assets/assets/js/back/core.js"></script>
<!-- Metis demo scripts -->
<script src="<?php echo $baseUrl ?>assets/assets/js/back/app.js"></script>


<script src="<?php echo $baseUrl ?>assets/assets/js/back/style-switcher.js"></script>
<script src="assets/lib/jquery/jquery.js"></script>

<script src="//cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.13.1/jquery.validate.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/holder/2.4.1/holder.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/Uniform.js/2.1.2/jquery.uniform.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jasny-bootstrap/3.1.3/js/jasny-bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery.form/3.51/jquery.form.min.js"></script>





<script src="<?php echo $baseUrl ?>/assets/lib/plupload/js/plupload.full.min.js"></script>
<script src="<?php echo $baseUrl ?>/assets/lib/plupload/js/jquery.plupload.queue/jquery.plupload.queue.min.js"></script>
<script src="<?php echo $baseUrl ?>/assets/lib/jquery.gritter/js/jquery.gritter.min.js"></script>
<script src="<?php echo $baseUrl ?>/assets/lib/formwizard/js/jquery.form.wizard.js"></script>
<script src="<?php echo $baseUrl ?>assets/ajax.js"></script>

<!-- Metis core scripts -->
<script src="<?php echo $baseUrl ?>assets/js/core.js"></script>
<!-- Metis demo scripts -->
<script src="<?php echo $baseUrl ?>assets/js/app.js"></script>