<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 22/01/2018
 * Time: 10:29
 */
?>
    <!doctype html>
    <html>
    <!-- head -->
    <?php
    $this->load->view("back/templates/head");
    ?>

    <body class="  ">
    <div class="bg-dark dk" id="wrap">
        <!-- top -->
        <?php
        $this->load->view("back/templates/top");
        ?>

        <!-- left -->
        <?php
        $this->load->view("back/templates/left");
        ?>

        <!-- content -->
        <div id="content">
            <div class="outer">
                <div class="inner bg-light lter">
                    <div class="col-lg-12">
                        <?php
                        $this->load->view($contenu);
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /#wrap -->

    <!-- footer -->
    <?php
    $this->load->view("back/templates/footer");
    ?>

    <!-- js -->
    <?php
    $this->load->view("back/templates/js");
    ?>
    </body>
    </html>


