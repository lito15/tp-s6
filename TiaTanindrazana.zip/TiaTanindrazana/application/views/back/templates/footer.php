<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 22/01/2018
 * Time: 10:29
 */
?>
<footer class="Footer bg-dark dker">
    <p>2017 &copy; Metis Bootstrap Admin Template v2.4.2</p>
</footer>
<!-- /#footer -->
