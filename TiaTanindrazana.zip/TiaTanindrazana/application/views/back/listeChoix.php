<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 22/01/2018
 * Time: 11:00
 */
?>

<div class="row">
    <!-- .col-lg-6 -->
    <div class="col-lg-12">
        <div class="box">
            <header>
                <h5>Choisir la nouvelle</h5>
                <div class="toolbar">
                    <div class="btn-group">
                        <a href="#defaultTable" data-toggle="collapse" class="btn btn-sm btn-default minimize-box">
                            <i class="fa fa-angle-up"></i>
                        </a>
                        <a class="btn btn-danger btn-sm close-box"><i class="fa fa-times"></i></a>
                    </div>
                </div>
            </header>
            <div id="defaultTable" class="body collapse in">
                <table class="table responsive-table">
                    <thead>
                    <tr>
                        <th>titre</th>
                        <th>daty</th>
                        <th>type</th>
                        <th>option</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($all as $row){ ?>
                        <tr>
                            <th><?php echo($row['titre']); ?></th>
                            <td><?php echo($row['daty']); ?></td>
                            <td><?php echo($row['idType']); ?></td>
                            <td><a href="udpateAccueil-<?php echo($row['Id']); ?>-<?php echo($row['Id']); ?>.html"><button class="btn btn-danger">Ok</button></a></td>
                        </tr>

                    <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- /.col-lg-6 -->

    <!-- .col-lg-6 -->

    <!-- /.col-lg-6 -->
</div>
