<?php
/**
 * Created by PhpStorm.
 * User: Joselito
 * Date: 31/03/2018
 * Time: 19:31
 */
$baseUrl = base_url();
?>
<head>
    <title><?php echo($title); ?></title>
    <meta charset="utf-8" content="site creer par joselito cedric RAZAFIMANDIMBY etudiant à l'ITU" />
    <meta name="viewport"/>
    <!--[if lte IE 8]><script src="<?php echo $baseUrl ?>assets/js/ie/html5shiv.js"></script><![endif]-->
    <link rel="stylesheet" href="<?php echo $baseUrl ?>assets/css/main.css" />
    <!--[if lte IE 9]><link rel="stylesheet" href="<?php echo $baseUrl ?>assets/css/ie9.css" /><![endif]-->
    <!--[if lte IE 8]><link rel="stylesheet" href="<?php echo $baseUrl ?>assets/css/ie8.css" /><![endif]-->
</head>
