<?php
/**
 * Created by PhpStorm.
 * User: Joselito
 * Date: 31/03/2018
 * Time: 19:37
 */
?>
<section class="blurb">
    <h2>About</h2>
    <p>Site Creer par RAZAFIMANDIMBY Joselito Cedric. Numero 591</p>

</section>
