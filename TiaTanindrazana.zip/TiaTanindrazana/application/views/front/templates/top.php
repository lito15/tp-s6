<?php
/**
 * Created by PhpStorm.
 * User: Joselito
 * Date: 31/03/2018
 * Time: 19:39
 */
?>
<!-- Header -->
<header id="header">
    <h1><a href="#">Le journal</a></h1>
    <nav class="links">
        <ul>
            <li><a href="admin">Admin</a></li>
        </ul>
    </nav>
</header>

<!-- Menu -->
<section id="menu">

    <!-- Search -->


    <!-- Links -->


    <!-- Actions -->


</section>
