<?php
/**
 * Created by PhpStorm.
 * User: Joselito
 * Date: 31/03/2018
 * Time: 19:43
 */
$baseUrl = base_url();
?>
<script src="<?php echo $baseUrl ?>assets/js/jquery.min.js"></script>
<script src="<?php echo $baseUrl ?>assets/js/skel.min.js"></script>
<script src="<?php echo $baseUrl ?>assets/js/util.js"></script>
<!--[if lte IE 8]><script src="<?php echo $baseUrl ?>assets/js/ie/respond.min.js"></script><![endif]-->
<script src="<?php echo $baseUrl ?>assets/js/main.js"></script>
