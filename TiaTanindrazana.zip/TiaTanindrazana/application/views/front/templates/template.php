<?php
/**
 * Created by PhpStorm.
 * User: Joselito
 * Date: 31/03/2018
 * Time: 19:45
 */
?>
<!DOCTYPE HTML>
<!--
	Future Imperfect by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
<?php
$this->load->view("front/templates/head");
?>
<body>
<?php
$this->load->view("front/templates/top");
?>
<div id="wrapper">
        <?php
        $this->load->view($contenu);
        ?>
        <?php
        $this->load->view("front/templates/about");
        ?>
        <?php
        $this->load->view("front/templates/footer");
        ?>
</section>

</div>
<?php
$this->load->view("front/templates/js");
?>
</body>

</html>
