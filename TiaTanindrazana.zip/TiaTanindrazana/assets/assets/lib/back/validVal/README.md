jquery.validVal
===============

A highly customizable and feature rich jQuery form validator plugin that embraces the power of HTML5.
For examples and the complete documentation, visit http://validval.frebsite.nl
